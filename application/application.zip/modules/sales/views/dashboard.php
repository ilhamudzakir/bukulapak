<section class="martop">
	<div class="container">
		<div class="col-md-9">
    <div class="float-l"><h2 class="grey">Lapak Saya</h2></div><div class="float-l" id="info">
    <div class="wrapper">
        <div class="content">
            <ul>
                <a href="#"><li>Tampilkan Semua Lapak</li></a>
                <a href="#"><li>Lapak Aktif</li></a>
                <a href="#"><li>Lapak Menunggu Persetujuan</li></a>
                <a href="#"><li>Lapak Approved</li></a>
                <a href="#"><li>Lapak Tidak Aktif</li></a>
            </ul>
        </div>
        <div class="parent"><img src="assets/front/images/dropdown.png" /></div>
    </div>
    </div>
    <div class="col-md-3 pull-right">
       <a href="sales/add"><button type="submit" name="submit" class="form btn2 large2">+ Buat Lapak Baru</button></a>
    </div>
    <div class="clearfix"></div>
    <div>


      <div class="kotak4">
     <a href="sales/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
      <div class="col-md-2"><a href="sales/edit"><input type="submit" class="form btn2 b-grey" value="Edit" name="submit"></a></div>
     </div>
    </div>

          <div class="kotak4">
     <a href="sales/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
      <div class="col-md-2"><a href="sales/edit"><input type="submit" class="form btn2 b-grey" value="Edit" name="submit"></a></div>
     </div>
    </div>

          <div class="kotak4">
     <a href="sales/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
      <div class="col-md-2"><a href="sales/edit"><input type="submit" class="form btn2 b-grey" value="Edit" name="submit"></a></div>
     </div>
    </div>

          <div class="kotak4">
     <a href="sales/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
      <div class="col-md-2"><a href="sales/edit"><input type="submit" class="form btn2 b-grey" value="Edit" name="submit"></a></div>
     </div>
    </div>


    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>