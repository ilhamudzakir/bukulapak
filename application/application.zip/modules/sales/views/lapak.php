<section class="martop2">
	<div class="container">
		<div class="col-md-9">
    <div class="col-md-12 bortom-large"><h2 class="grey">Lapak Aktif (5)</h2></div>

    <div class="clearfix"></div>
    <div>


      <div class="kotak4">
     <div class="row">
       <div class="col-md-8 grey2">
        <a href="sales/detail"><h3 class="grey">LAPAK12321</h3></a>
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
       </div>
       <div class="col-md-4">
        <span class="grey2">by</span>
        <h3>Mahmud Yaya</h3>
        <span class="grey2">Total Penjualan (5 item)</span>
        <h4 class="grey">1.500.000</h4>
       </div>
     </div>
    </div>


    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>