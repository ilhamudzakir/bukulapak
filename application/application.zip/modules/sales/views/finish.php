<section>
	<div class="container">
		<div class="col-md-9">
    <h4 class="grey">Lapak Saya > Lapak Baru</h4>
    <div class="clearfix"></div>
      
          <div class="kotak4">
    <div class="martop text-center">
      <h1>Lapak berhasil di buat</h1>
      <div class="martop grey"><h3 >Kode Lapak anda adalah <b>890421</b></h3>
      <h3>selanjutnya atasan anda akan memeriksa dan melakukan persetujuan setelah lapak anda disetujui anda bisa mulai menggunakan lapak tersebut</h3>
      </div>
      <div class="martop2">
        <div class="col-md-6">
          <button type="submit" name="submit" class="form btn2 large2">+ Buat Lapak Baru</button>
        </div>
                <div class="col-md-6">
          <button type="submit" name="submit" class="form btn2 large2">Tampilkan Lapak</button>
        </div>
        <div class="col-md-6"></div>
      </div>
    </div>
    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>