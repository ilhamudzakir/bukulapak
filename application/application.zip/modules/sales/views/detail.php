<section>
	<div class="container">
		<div class="col-md-9">
    <h4 class="grey">Lapak Saya > Lapak 892174</h4>
    <div class=""><h2 class="grey">Lapak Saya</h2></div>
    <div class="clearfix"></div>
      
          <div class="kotak4">
     <h3 class="grey">LAPAK12321</h3>
     <div class="row">
       <div class="col-md-10 grey2">
        
         <h5 class="green">Aktif</h5>
       </div>
      </div>
      <div class="row">
           <div class="col-md-2">
       <a href="sales/edit"><input type="submit" class="form btn2 b-grey" value="Edit" name="submit"></a>
       </div>
       
       <div class="col-md-12 grey2">
        <span>Masa aktif: 23 Jan 2016 - 23 Agustus 2016</span></br>
        <span>Dibuat Pada: 23 Jan 2016 Jam 12:34</span></br>
       </div>
       
       <div class="col-md-6 grey2 martop">
         <span>DKI Jakarta, Jakarta Selatan</span></br>
        <span>SMA Negri 1 Ciawi</span></br>
        <span>Kelas: 3IPA1</span></br>
        <span>Nama Agen : Ilham Mudzakir</span></br>
       </div>

       <div class="col-md-6 grey2 martop">
          <span>Total Sales: 55 Buku</span></br>
          <h1 class="grey">1.500.000</h1>
       </div>

      </div>
      <div class="martop2">
        <table class="width-seratus">
          <tr class="border-top-grey">
            <td colspan="2" width="40%"><h3>Buku</h3></td>
            <td class="text-center"><h3>Penjualan</h3></td>
          <td class="text-center"><h3>Subtotal</h3></td>
          </tr>
           <tr class="border-top-grey">
            <td class="patop-20"><img src="assets/front/images/book.jpg" width="90"></td>
            <td class="patop-20"> <span class="grey">Judul Buku</span></br><h3 class="grey">45000</h3></td>
            <td class="text-center patop-20"><h3 class="grey">5</h3></td>
          <td class="text-center patop-20"> <h3 class="grey">500000</h3></td>
          </tr>
                     <tr class="border-top-grey">
            <td class="patop-20"><img src="assets/front/images/book.jpg" width="90"></td>
            <td class="patop-20"> <span class="grey">Judul Buku</span></br><h3 class="grey">45000</h3></td>
            <td class="text-center patop-20"><h3 class="grey">5</h3></td>
          <td class="text-center patop-20"> <h3 class="grey">500000</h3></td>
          </tr>
                     <tr class="border-top-grey">
            <td class="patop-20"><img src="assets/front/images/book.jpg" width="90"></td>
            <td class="patop-20"> <span class="grey">Judul Buku</span></br><h3 class="grey">45000</h3></td>
            <td class="text-center patop-20"><h3 class="grey">5</h3></td>
          <td class="text-center patop-20"> <h3 class="grey">500000</h3></td>
          </tr>
                     
          
        </table>
      </div>
    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>