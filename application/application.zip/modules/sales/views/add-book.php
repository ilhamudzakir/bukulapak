<section>
	<div class="container">
		<div class="col-md-9">
    <h4 class="grey">Lapak Saya > Lapak 892174</h4>
    <div class=""><h2 class="grey">LAPAK214798</h2></div>
    <div class="clearfix"></div>
      
          <div class="kotak4 grey">
    <form>
      <div class="form-group">
        <h3 class="grey">Tambah Buku</h3>
      </div>
      <div class="form-group">
        <div class="row">
        <div class="col-md-9">
            <div class="col-md-12">
             <div class="row">
              <input type="text" name="name" placeholder="Kode Buku" class="form border">
              </div>
            </div>
            <div class="col-md-4 padding-none">
             
             <label>Jenjang</label>
              <select class="form border arrow-sel">
                    <option value="">SMA</option>
                  </select>
              
            </div>
            <div class="col-md-3">
             
             <label>Kelas</label>
              <select class="form border arrow-sel">
                    <option value="">III</option>
                  </select>
              
            </div>

            <div class="col-md-5 padding-none">
             
             <label>Judul Buku</label>
              <input type="text" name="name" placeholder="Kode Buku" class="form border">
              
            </div>
            

        </div>
        <div class="col-md-3">
          <button type="submit" name="submit" class="form btn2 large">Cari</button>
        </div>
        <div class="col-md-12 martop bortomtop">
          <div class="list-book">
          <div class="col-md-2"> <img width="80" src="assets/front/images/book.jpg"></div>
           <div class="col-md-3">
          <h4>Judul Buku</h4>
          <h4 class="price-list">RP 45.000</h4>
          
           </div>
           <div class="col-md-4">
           <div class="row">
                <div class="col-md-12">
                  <label>Kelas</label>
                  <input type="text" class="form border" name="">
                </div>
                
           </div>
          
           </div>
            <div class="col-md-3">
            <div class="row">
            </br>
                 <input type="submit" class="form btn2 large" value="Tambahkan buku ini" name="submit">
                 </div>
                </div>
           <div class="clearfix"></div>
       </div>
        </div>
      </div>
      </div>
    </form>
     </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>