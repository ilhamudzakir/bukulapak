<div class="page-content">
  <div class="content">
    <div class="grid simple">
      <div class="row">
        <div class="col-md-9">
          <?php echo $this->session->flashdata('message_success');?>
          <input type="hidden" id="controller_name" value="<?php echo $controller_name; ?>">
          <div class="grid-title">
            <div class="row">
              <div class="col-md-12">
                <h3>Data Lapak Sebagai Atasan 2</h3>
              </div>
            </div>
          </div>
          <div class="grid-body ">
            <table id="table_atasan_2" class="table" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>Nama Lapak</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-md-3">
          <h2>RANGKUMAN</h2>
          <h4>Total Penjualan</h4>
          <div class="">IDR. 3,000,000</div>
          <h4>Lapak</h4>
          <ul>
            <li>5 Aktif</li>
            <li>5 Menunggu Persetujuan</li>
            <li>5 Approve</li>
            <li>5 Tidak Approve</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- <div class="page-content">
  <div class="content">
    <div class="grid simple">
    <input type="hidden" id="controller_name" value="<?php echo $controller_name; ?>">
    <div class="grid-title">
      <h3>Data Lapak sebagai Atasan 2</h3>
    </div>
    <div class="grid-body ">
    <br />
    <br />
    <table id="table_atasan_2" class="table" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>ID</th>
          <th>Lapak</th>
          <th>Nama Sekolah</th>
          <th>Agen</th>
          <th>Aktif</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>
  </div>
  </div>
</div> -->


        



        
  