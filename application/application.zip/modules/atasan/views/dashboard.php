<section class="martop2">
	<div class="container">
		<div class="col-md-9">
    <div>

<ul  class="nav nav-pills  nev-pills plsi" id="p-sekolah">
    <li class="active tabse tab-atasan" id="setuju">
          <a  href="#tab-setuju" data-toggle="tab">Permintaan Persetujuan <span> 3 </span></a>
    </li>
    <li class="tabse tab-atasan" id="lainya">
      <a href="#tab-lainya" data-toggle="tab">Notifikasi Lainya <span> 3 </span></a>
    </li>
</ul>
<div class="line-small">
</div>

<div class="tab-content clearfix">
    <div class="tab-pane bet active" id="tab-setuju">

<div class="kotak4">
     <div class="row">
       <div class="col-md-8 grey2">
        <a href="atasan/detail"><h3 class="grey">LAPAK12321</h3></a>
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
       </div>
       <div class="col-md-4">
        <span class="grey2">request by</span>
        <h3>Mahmud Yaya</h3>
        <span class="grey2">Approval</span>
        <h4 class="grey"><span style="text-decoration: line-through;">Selamat</span><span> Nurdin</span></h4>
       </div>
     </div>
    </div>
     



  </div>



<div class="tab-pane bet" id="tab-lainya">

  <div class="kotak4">
     <div class="row">
      <div class="col-md-8 grey2">
      <a href="atasan/detail"><h3 class="grey">LAPAK12321</h3></a>
      </div>
       <div class="col-md-8 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
       </div>
       <div class="col-md-4">
        <h3 class="grey">Perubahan Buku</h3>
       </div>
     </div>
    </div>
     
</div>



  </div></div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>