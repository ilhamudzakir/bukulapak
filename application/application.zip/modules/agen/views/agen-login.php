<section>
	<div class="container">
		<div class="title1"><h3>Login Agen</h3></div>
		<div class="col-md-4 center kotak3">
			<form action="agen/dashboard">
				<div class="form-group">
					<label class="grey">ID Agen</label>
					<input type="text" name="id" class="form">
				</div>
				<div class="form-group">
					<label class="grey">Password</label>
					<input type="password" name="pass" class="form">
				</div>
				<div class="form-group">
					<input type="submit" name="submit" value="Submit" class="form btn2 large">
				</div>
			</form>
		</div>
	</div>
</section>
