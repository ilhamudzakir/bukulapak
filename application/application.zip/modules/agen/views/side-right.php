    <div class="col-md-3">
     <div class="side-right">
     	<h2 class="grey">Rangkuman</h2>
     	<h4 class="martop grey">Total Penjualan</h4>
     	<h2>3.000.000</h2>
     
     	<div class="martop2"><a href="agen/edit_profile"><button class="form btn2 large2" name="submit" type="submit">Edit Profile</button></a></div>
      <div><a href="agen/edit_password"><button class="form btn2 large2" name="submit" type="submit">Ganti Password</button></a></div>
     </div>
    </div>
