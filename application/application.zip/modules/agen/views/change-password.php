<section>
	<div class="container">
		<div class="col-md-9">
    <div><h2  class="grey">Edit Profile</h2></div>
    <div class="clearfix martop"></div>
    <div>
    <form>
    	
    	<div class="form-group">
    		<div class="col-md-6 float-n">
    				<h4 class="grey">Password Lama</h4>
    				<input type="password" name="pass" class="form border">
    		</div>
            </div>
            <div class="form-group">
            <div class="col-md-6 float-n">
                    <h4 class="grey">Password Baru</h4>
                    <input type="password" name="pass" class="form border">
            </div>
            </div>
            <div class="form-group">
            <div class="col-md-6 float-n">
                    <h4 class="grey">Password Baru (sekali lagi)</h4>
                    <input type="password" name="pass" class="form border">
            </div>
    	</div>
    </form>

    
    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>