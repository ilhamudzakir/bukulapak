<section>
	<div class="container">
		<div class="col-md-9">
    <div><h2 class="grey">Lapak Saya</h2></div>
    <div class="clearfix"></div>
    <div>


      <div class="kotak4">
     <a href="agen/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
     </div>
    </div>

    <div class="kotak4">
     <a href="agen/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
     </div>
    </div>

    <div class="kotak4">
     <a href="agen/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
     </div>
    </div>

    <div class="kotak4">
     <a href="agen/detail"><h3 class="grey">LAPAK12321</h3></a>
     <div class="row">
       <div class="col-md-6 grey2">
         SMA Negrei 1 Ciawi</br>
         Masa aktif : 23 Jan 2016 - 23 Agus 2018
         <h5 class="green">Aktif</h5>
       </div>
       <div class="col-md-4">
        <span class="grey2">Total Sales:55 buku</span>
        <h4 class="grey">1.500.000</h4>
       </div>
     </div>
    </div>


     
    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>