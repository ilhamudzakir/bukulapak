<section>
	<div class="container">
		<div class="col-md-9">
    <div><h2  class="grey">Edit Profile</h2></div>
    <div class="clearfix martop"></div>
    <div>
    <form>
    	<div class="form-group">
    		<div class="col-md-6">
    				<h4 class="grey">User ID</h4>
    				<h2>5431</h2>
    		</div>
    		<div class="col-md-6">
    				<h4 class="grey">Nama</h4>
    				<h2>Suparman</h2>
    		</div>
    	</div>
    	<div class="form-group">
    		<div class="col-md-6">
    				<h4 class="grey">Email</h4>
    				<input type="email" name="email" class="form border">
    		</div>
    		<div class="col-md-6">
    				<h4 class="grey">Nomor Telepon</h4>
    				<input type="text" name="tlp" class="form border">
    		</div>
    	</div>
    </form>

    
    </div>
     </div>


<?php $this->load->view('side-right'); ?>

	</div><!----end container-------------->
</section>