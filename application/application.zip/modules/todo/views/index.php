<h1 class="page-header">Todo example</h1>

<?php echo $pagelet_todo; ?>

<?php
// As it was designed to be an independent component,
// you can try to use the todo pagelet anywhere.
// echo '<hr>';
// echo Modules::run('todo/_pagelet_todo');
?>