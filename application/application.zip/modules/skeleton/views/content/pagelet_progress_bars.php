<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>.progress</strong></p>
    <div class="progress">
        <div class="progress-bar" style="width: 50%;">
            <span>.progress-bar</span>
        </div>
    </div>
</div>

<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>.progress</strong></p>
    <div class="progress">
        <div class="progress-bar progress-bar-success" style="width: 60%;">
            <span>.progress-bar.progress-bar-success</span>
        </div>
        <div class="progress-bar progress-bar-info" style="width: 30%;">
            <span>..progress-bar-info</span>
        </div>
    </div>
</div>

<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>.progress</strong></p>
    <div class="progress">
        <div class="progress-bar progress-bar-warning" style="width: 60%;">
            <span>.progress-bar.progress-bar-warning</span>
        </div>
        <div class="progress-bar progress-bar-danger" style="width: 30%;">
            <span>..progress-bar-danger</span>
        </div>
    </div>
</div>

<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>.progress.progress-striped</strong></p>
    <div class="progress progress-striped">
        <div class="progress-bar" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-success" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-info" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-warning" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-danger" style="width: 17%;"></div>
    </div>
</div>

<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>.progress.progress-striped.active</strong></p>
    <div class="progress progress-striped active">
        <div class="progress-bar" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-success" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-info" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-warning" style="width: 17%;"></div>
        <div class="progress-bar progress-bar-danger" style="width: 17%;"></div>
    </div>
</div>