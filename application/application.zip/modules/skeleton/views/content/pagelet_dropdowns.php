<div class="clearfix js-html-inspector" data-remove-target="p:first">
    <p><strong>.dropdown ul.dropdown-menu</strong></p>
    <div class="dropdown">
        <!-- Only use inline style for static display -->
        <ul class="dropdown-menu" style="display: block; position: static;">
            <li class="dropdown-header">li.dropdown-header</li>
            <li><a href="#">li a</a></li>
            <li><a href="#">Another link</a></li>
            <li class="disabled"><a href="#">li.disabled a</a></li>
            <li class="divider"></li>
            <li class="dropdown-header">Dropdown header</li>
            <li><a href="#">Separated link</a></li>
        </ul>
    </div>
</div>