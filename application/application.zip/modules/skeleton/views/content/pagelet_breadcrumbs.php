<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>ol.breadcrumb</strong></p>
    <ol class="breadcrumb">
        <li><a href="#">li a</a></li>
        <li><a href="#">Link #2</a></li>
        <li class="active">li.active</li>
    </ol>
</div>