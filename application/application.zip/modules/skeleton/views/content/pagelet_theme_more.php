<div class="btn-group">
    <a href="#" class="btn btn-default disabled">Learn more</a>
    <a href="http://getbootstrap.com/css/#grid" target="_blank" class="btn btn-primary">Grid system</a>
    <a href="http://getbootstrap.com/components/#thumbnails" target="_blank" class="btn btn-primary">Thumbnails</a>
    <a href="http://getbootstrap.com/components/#media" target="_blank" class="btn btn-primary">Media object</a>
</div>