<div class="js-html-inspector" data-remove-target="p:first">
    <p><strong>.jumbotron</strong></p>
    <div class="jumbotron">
        <h1>h1</h1>
        <p>p</p>
        <p><a class="btn btn-primary">p Button</a></p>
    </div>
</div>