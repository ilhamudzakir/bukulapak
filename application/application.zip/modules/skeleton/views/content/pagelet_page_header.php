<div class="js-html-inspector">
    <div class="page-header">
        <h3>
            .page-header h3
            <small>small</small>
        </h3>
    </div>
</div>