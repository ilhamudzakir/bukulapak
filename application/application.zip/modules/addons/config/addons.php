<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['list'] = array(
    'bs_form_helpers' => 'Bootstrap form helpers',
    'ion_auth' => 'Ion auth',
    'jquery_file_upload' => 'jQuery file upload',
    'validate_js' => 'validate.js',
);

/* End of file addons.php */
/* Location: ./application/modules/addons/config/addons.php */