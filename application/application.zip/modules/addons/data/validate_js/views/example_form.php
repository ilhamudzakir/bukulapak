<div class="page-header">
    <h1>Form validation example</h1>
</div>

<div>
    <?php echo $pagelet_example_form; ?>
</div>