<p>
    Form validation example:
    <a href="<?php echo site_url('form_validation_example'); ?>"
        rel="async" ajaxify="<?php echo site_url('form_validation_example/form_validation_example_ajax/dialog_example'); ?>"
        class="btn btn-primary"
    >
        Show dialog
    </a>
    <a href="<?php echo site_url('form_validation_example'); ?>" class="btn btn-primary" target="_blank">Open page</a>
</p>