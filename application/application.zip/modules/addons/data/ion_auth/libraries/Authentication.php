<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . 'libraries/Ion_auth/Ion_auth.php';

class Authentication extends Ion_auth {}

/* End of file Authentication.php */
/* Location: ./application/libraries/Authentication.php */