<p>
    <a href="<?php echo site_url('photo/upload'); ?>"
        rel="async" ajaxify="<?php echo site_url('photo/photo_ajax/dialog_upload'); ?>"
        class="btn btn-primary"
    >
        Show photo upload dialog
    </a>
    <a href="<?php echo site_url('photo/upload'); ?>" class="btn btn-primary" target="_blank">Open photo upload page</a>
</p>
<p>
    <a href="#"
        rel="async" ajaxify="<?php echo site_url('photo/photo_ajax/dialog_upload_plus'); ?>"
        class="btn btn-primary"
    >
        Show photo upload plus dialog
    </a>
</p>