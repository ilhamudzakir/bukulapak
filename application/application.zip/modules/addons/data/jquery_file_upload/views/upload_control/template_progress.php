<hr>
<div class="progress hide">
    <div class="progress-bar progress-bar-primary"></div>
</div>