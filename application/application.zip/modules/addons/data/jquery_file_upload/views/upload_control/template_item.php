<div class="media alert alert-success">
    <a href="{{url}}" class="pull-left" target="_blank">
        <img src="{{thumbnailUrl}}">
    </a>
    <div class="media-body"><h4>{{name}}</h4>{{type}}</div>
</div>