<div class="page-header">
    <h1>Photo Upload</h1>
</div>

<div>
    <?php echo $pagelet_upload_control; ?>
</div>