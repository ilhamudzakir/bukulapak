<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/jQuery_file_upload/Uploadhandler.php';

class Uploader extends Uploadhandler {}

/* End of file Uploader.php */
/* Location: ./application/libraries/Uploader.php */