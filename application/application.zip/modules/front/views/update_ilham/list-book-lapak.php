<section>
<div class="title2">
     <div class="container">
          <div class="col-md-6 pull-left"><h3>838lapaksatu</h3>
          <span>SMP Rawa Buaya</span>
          </div>
          <div class="col-md-3 pull-right text-right"> 
            <a href="<?php echo base_url() ?>"><button class="form btn1" name="submit" type="submit">
<span id="search">Cari</span>
</button>
</a>
          </div>
     </div>
</div>
</section>
<section>
	<div class="container">
		<div class="kotak">
         
        <!------------------------list---------------->
       <div class="list-book">
          <div class="col-md-3"> <a href="front/book/detail"><img src="assets/front/images/book.jpg" width="130px"></a></div>
           <div class="col-md-5">
          <a href="front/book/detail"><h4>Lorem Ipsum Dolor Amet</h4></a>
          <span>Bidang studi, Nama Pengarang</span><br/>
          <span>Kelas II IPA 2</span>
           <div class="ko-price">
          <h4 class="price-list">RP 45.000</h4>
          </div>
           </div>
           <div class="col-md-4 text-right">
           <form action="front/cart">
           <div class="row">
                <div class="col-md-12">
                    <select class="form border arrow-sel">
               <option value="1">1 Buku</option>
          </select> 
                </div>
                 <div class="col-md-12">
                 <input type="submit" name="submit" value="Beli" class="form btn2">
                </div>
           </div>
          </form>
           </div>
           <div class="clearfix"></div>
       </div><!--endlist--> 
               <!------------------------list---------------->
       <div class="list-book">
          <div class="col-md-3"> <a href="front/book/detail"><img src="assets/front/images/book.jpg" width="130px"></a></div>
           <div class="col-md-5">
          <a href="front/book/detail"><h4>Lorem Ipsum Dolor Amet</h4></a>
          <span>Bidang studi, Nama Pengarang</span><br/>
          <span>Kelas II IPA 2</span>
           <div class="ko-price">
          <h4 class="price-list">RP 45.000</h4>
          </div>
           </div>
           <div class="col-md-4 text-right">
           <form action="front/cart">
           <div class="row">
                <div class="col-md-12">
                    <select class="form border arrow-sel">
               <option value="1">1 Buku</option>
          </select> 
                </div>
                 <div class="col-md-12">
                 <input type="submit" name="submit" value="Beli" class="form btn2">
                </div>
           </div>
          </form>
           </div>
           <div class="clearfix"></div>
       </div><!--endlist--> 
               <!------------------------list---------------->
       <div class="list-book">
          <div class="col-md-3"> <a href="front/book/detail"><img src="assets/front/images/book.jpg" width="130px"></a></div>
           <div class="col-md-5">
          <a href="front/book/detail"><h4>Lorem Ipsum Dolor Amet</h4></a>
          <span>Bidang studi, Nama Pengarang</span><br/>
          <span>Kelas II IPA 2</span>
           <div class="ko-price">
          <h4 class="price-list">RP 45.000</h4>
          </div>
           </div>
           <div class="col-md-4 text-right">
           <form action="front/cart">
           <div class="row">
                <div class="col-md-12">
                    <select class="form border arrow-sel">
               <option value="1">1 Buku</option>
          </select> 
                </div>
                 <div class="col-md-12">
                 <input type="submit" name="submit" value="Beli" class="form btn2">
                </div>
           </div>
          </form>
           </div>
           <div class="clearfix"></div>
       </div><!--endlist--> 
               <!------------------------list---------------->
       <div class="list-book">
          <div class="col-md-3"> <a href="front/book/detail"><img src="assets/front/images/book.jpg" width="130px"></a></div>
           <div class="col-md-5">
          <a href="front/book/detail"><h4>Lorem Ipsum Dolor Amet</h4></a>
          <span>Bidang studi, Nama Pengarang</span><br/>
          <span>Kelas II IPA 2</span>
           <div class="ko-price">
          <h4 class="price-list">RP 45.000</h4>
          </div>
           </div>
           <div class="col-md-4 text-right">
           <form action="front/cart">
           <div class="row">
                <div class="col-md-12">
                    <select class="form border arrow-sel">
               <option value="1">1 Buku</option>
          </select> 
                </div>
                 <div class="col-md-12">
                 <input type="submit" name="submit" value="Beli" class="form btn2">
                </div>
           </div>
          </form>
           </div>
           <div class="clearfix"></div>
       </div><!--endlist-->        
       
          </div>

	</div><!----end container-------------->
</section>