<section>
<div class="title2">
     <div class="container">
          <div class="col-md-6 pull-left padding-botop"><h3></h3> </div>
          <div class="col-md-3 pull-right text-right">
            <a href="<?php echo site_url() ?>"><button class="form btn1" name="submit" type="submit">
<span id="search">Cari</span>
</button>
</a>
          </div>
         
         
     </div>
</div>
</section>
<section class="matobot">
	<div class="container text-center">
  <h1><b>Terima Kasih,</b></h1>
  <h4>Nomor transaksi anda adalah <b><?php echo $order_code; ?></b></h4>
  <h4>selanjutnya silahkan melakukan pembayaran sebesar <b>RP <?php echo number_format($order_total); ?></b> ke nomor rekening berikut</h4>
  </br>
  <h4><b>Rekening Bank Permata</b></h4>
  <h4>Bank Permata Cabang Kyai Hasyim Jakarta</h4>
  <h4>atas nama : PT Erlangga</h4>
  <h4>Nomor rekening : 451376137813</h4>
   </br>
    </br>
        </br>
            </br>
            <div class="row">
  <div class="text-left col-md-7 center" style="padding-left:50px">
  <h4>+ Kami juga telah mengirimkan detail transaksi ini ke alamat email Anda</h4>
  <h4>+ Catat nomor transaksi anda</h4>
  <h4>+ Setelah melakukan transfer lakukan <b>konfirmasi pembayaran</b></h4>
  </div>
  </div>
	</div><!----end container-------------->
</section>