<section>
<div class="title2">
     <div class="container">
          <div class="col-md-6 pull-left"><h3>838lapaksatu</h3>
          <span>SMP Rawa Buaya</span>
          </div>
          <div class="col-md-6 pull-right text-right"> <input type="button" name="cari" class="btn3" value="Cari buku lainya"></div>
     </div>
</div>
</section>
<section>
	<div class="container">
		<div class="kotak">
        
        <!------------------------list---------------->
       <div class="list-book">
          <div class="col-md-3"> <img src="assets/front/images/book.jpg" width="180px"></div>
           <div class="col-md-9">
          <h3>Lorem Ipsum Dolor Amet</h3>
         <div class="desc">
           Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<br/>
           <br/>
           "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.
         </div>
           </div>
           <div class="col-md-12 text-center">
           <div class="row">
           <div class="col-md-6 center">
                <div class="col-md-6">
                    <select class="form border arrow-sel">
               <option value="1">1 Buku</option>
          </select> 
                </div>
                 <div class="col-md-6">
                 <input type="submit" name="submit" value="Beli" class="form btn2">
                </div>
                </div>
           </div>
          
           </div>
           <div class="clearfix"></div>
       </div><!--endlist-->        
          </div>

	</div><!----end container-------------->
</section>