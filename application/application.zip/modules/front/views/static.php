<section>
<div class="title2">
     <div class="container">
          <div class="col-md-6 text-center center"><h3><?php echo $page->title ?></h3>
          </div>
         
     </div>
</div>
</section>
<section class="matobot">
  <div class="container">
<div class="col-md-8 center">
<div class="grey">
 <?php echo $page->content ?>
</div>
</div>

  </div><!----end container-------------->
</section>