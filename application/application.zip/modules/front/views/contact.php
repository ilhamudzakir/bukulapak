<section>
<div class="title2">
     <div class="container">
          <div class="col-md-6 text-center center"><h3>Contact Us</h3>
          </div>
         
     </div>
</div>
</section>
<section class="matobot">
  <div class="container">
<div class="col-md-6 center">
   <form>
    <div class="form-group marbot text-center">
      <h4><b>Silahkan lengkapi formulir berikut</b></h4>
    </div>
    <div class="form-group">
      <label class="grey">Nama</label>
      <input type="text" class="form border" name="name">
    </div>
      <div class="form-group">
      <div class="row">
      <div class="col-md-6">
        <label class="grey">Email</label>
      <input type="text" class="form border" name="name">
      </div>
      <div class="col-md-6">
        <label class="grey">Nomor Telpon</label>
         <input type="text" class="form border" name="name">
      </div>
    </div>
    </div>
      <div class="form-group">
     <label class="grey">Topik</label>
      <select class="form border arrow-sel">
                    <option value=""></option>
                  </select>
    </div>
    <div class="form-group">
     <label class="grey">Pesan</label>
     <textarea class="form border"></textarea>
    </div>
  
    <div class="form-group">
    <div class="col-md-6 center">
      <input type="submit" name="submit" value="Submit" class="form btn2 large">
    </div>
      
    </div>

      </div>
    </div>
  </form>  
</div>

  </div><!----end container-------------->
</section>