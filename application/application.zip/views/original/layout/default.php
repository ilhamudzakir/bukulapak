<?php echo $header; ?>

<div class="container">
    <?php echo $main_content; ?>
</div><!-- /.container -->

<?php echo $footer; ?>