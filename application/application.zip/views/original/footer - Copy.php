<div id="footer">
    <div class="container">
        <p class="footer-content">Place sticky footer content here</p>
    </div>
</div>