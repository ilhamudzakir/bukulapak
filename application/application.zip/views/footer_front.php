   <footer>
       <div class="footer-area">
    <div class="container">
        
            <div class="col-md-3">
            <div class="row">
                <h3>Pembelian</h3>
                <ul>
                    <li><a href="#">Cari Buku</a></li>
                    <li><a href="<?php echo base_url() ?>front/confirmation">Konfirmasi Pembayaran</a></li>
                    <li><a href="<?php echo base_url() ?>front/status">Status Transaksi</a></li>
                </ul>
                
            </div>
            </div>
        
        <div class="col-md-3">
            <div class="row">
                <h3>Bantuan</h3>
                <ul>
                    <li><a href="<?php echo base_url() ?>front/faq">FAQ</a></li>
                    <li><a href="<?php echo base_url() ?>front/cara_pembelian">Cara Pembelian</a></li>
                    <li><a href="<?php echo base_url() ?>front/cara_pembayaran">Cara Pembayaran</a></li>
                     <li><a href="<?php echo base_url() ?>front/cara_konfirmasi_pembayaran">Cara Konfirmasi Pembayaran</a></li>
                     <li><a href="<?php echo base_url() ?>front/terms">Syarat & Ketentuan</a></li>
                </ul>
                
            </div>
            </div>
        
        <div class="col-md-3">
            <div class="row">
                <h3>Hubungi Kami</h3>
                <ul>
                <li><span class="icon-location"></span>Jl H Baping Raya No 100 Ciracas Jakarta</li>
                <li><span class="icon-phone"></span>(021) 8717006 Ext 302</li>
                <li><span class="icon-fax"></span>(021) 87794609</li>
                <li><span class="icon-wa"></span>0819 0609 6020</li>
                </ul>
            </div>
            </div>
            <div class="col-md-3">
            <div class="row">
                <h3>Metode Pembayaran</h3>
                <img src="<?php echo base_url() ?>assets/front/images/icon-bca.png" alt="bca"/>&nbsp;&nbsp;&nbsp;
                <img src="<?php echo base_url() ?>assets/front/images/icon-mandiri.png" alt="bca"/>
                <br><br>
                <h3>Jasa Pengiriman</h3>  
                <img src="<?php echo base_url() ?>assets/front/images/logo-erureka-jne.png" alt="bca"/>
            </div>
            </div>
            <div class="col-md-6 pull-right"></div>
         <div class="row">
             <div class="col-md-12"><span class="text-copyright">Copyright © Erlangga 2016</span></div>
        </div>
    </div>
           </div>
    </footer>