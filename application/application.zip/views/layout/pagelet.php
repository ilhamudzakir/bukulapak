<?php //echo $header; ?>

<!-- <div class="container">
    <div class="row">
        <div class="col-lg-offset-3 col-lg-6"> -->
            <?php //echo $main_content; ?>
<!--         </div>
    </div>
</div> -->

<?php //echo $footer; ?>

<?php echo $header; ?>
<!-- BEGIN CONTENT -->
<div class="page-container row-fluid">
	<?php echo $sidebar; ?>
    <?php echo $main_content; ?>
</div>
<!-- END CONTENT -->

<?php echo $footer; ?>