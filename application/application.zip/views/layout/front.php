<?php echo $header; ?>
    
<?php echo $main_content; ?>
<?php //echo $page; ?>
    
<?php echo $footer; ?>