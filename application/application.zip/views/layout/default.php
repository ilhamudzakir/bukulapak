<?php echo $header; ?>
<!-- BEGIN CONTENT -->
<div class="page-container row-fluid">
	<?php echo $sidebar; ?>
    <?php echo $main_content; ?>
</div>
<!-- END CONTENT -->

<?php echo $footer; ?>