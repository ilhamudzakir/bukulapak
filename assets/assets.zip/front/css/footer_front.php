   <footer>
       <div class="footer-area">
    <div class="container">
    	
    		<div class="col-md-3">
    		<div class="row">
                <h3>Pembelian</h3>
                <ul>
                    <li><a href="#">Cari Buku</a></li>
                    <li><a href="<?php echo base_url() ?>front/confirmation">Konfirmasi Pembayaran</a></li>
                    <li><a href="<?php echo base_url() ?>front/status">Status Transaksi</a></li>
                </ul>
    			
    		</div>
    		</div>
        
        <div class="col-md-3">
    		<div class="row">
                <h3>Bantuan</h3>
                <ul>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Cara Pembelian</a></li>
                    <li><a href="#">Cara Pembayaran</a></li>
                     <li><a href="#">Cara Konfirmasi Pembayaran</a></li>
                     <li><a href="<?php echo base_url() ?>front/terms">Syarat & Ketentuan</a></li>
                </ul>
    			
    		</div>
    		</div>
        
        <div class="col-md-3">
    		<div class="row">
                <h3>Hubungi Kami</h3>
                
    		</div>
    		</div>
    		<div class="col-md-3">
    		<div class="row">
                <h3>Metode Pembayaran</h3>
                
    			
    		</div>
    		</div>
    		<div class="col-md-6 pull-right"></div>
    	
    </div>
           </div>
    </footer>